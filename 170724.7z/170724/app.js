const express = require('express');
const app = express();
const port = 3000;
const dotenv = require('dotenv');
const emailService = require('./emailService');

app.use(express.static('public'))
app.use(express.urlencoded({extended:false}));

app.post('/enviarEmail', async (req,res)=>{
    const {email, assunto,mensagem} = req.body;
    await emailService(email, assunto, mensagem);
    res.send("email enviado")

})

app.get('/', (req,res)=>{
    res.send('Hello World')
})


app.listen(port, ()=>{
    console.log(`http://localhost:${port}`);
})

